from .kamibot import *
from .version import *

