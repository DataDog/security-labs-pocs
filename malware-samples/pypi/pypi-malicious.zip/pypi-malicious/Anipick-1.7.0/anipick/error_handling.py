class TooManyRequests(Exception):
  pass
class NoResultFound(Exception):
  pass
class SearchNotWork(Exception):
  pass
class InvalidKey(Exception):
  pass