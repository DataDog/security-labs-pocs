from .animpedia import *
from .lyricsnim import *
from .quotepedia import *
from .char import *
from .manga import *
from .genshin import *
from .season import *
from .pict import *
from .secret import *

__version__ = '1.3.4'